-- ============================================================================
-- 印迹 · 云端数据表（与小蛋仓同一个 Supabase 项目，但用独立表，互不影响）
-- 用法：Supabase 控制台 → SQL Editor → 新建查询 → 粘贴本段 → Run
-- ============================================================================

create table if not exists public.yinji_data (
  user_id  uuid primary key references auth.users(id) on delete cascade,
  payload  jsonb        not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

-- 每个账号只能看到、只能改自己的那一行
alter table public.yinji_data enable row level security;

drop policy if exists "yinji_own_row" on public.yinji_data;
create policy "yinji_own_row" on public.yinji_data
  for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- 登录用户才能读写（匿名用户拿不到任何数据）
grant select, insert, update, delete on public.yinji_data to authenticated;

-- 可选：给这张表开实时订阅（以后想做成「多设备实时」再开）
-- alter publication supabase_realtime add table public.yinji_data;
