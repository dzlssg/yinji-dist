/* ==================== 印迹 · 账户与云同步（Supabase 直连） ====================
 * 与小蛋仓同一套后端思路：Supabase Auth（邮箱+密码）+ Postgres 表 + RLS 按用户隔离，
 * 整包 Last-Write-Wins 同步。本模块运行在父文档，负责：
 *   1) 注册 / 登录 / 登出 / 改密（弹层 UI 由本模块动态生成，样式与印迹一致）
 *   2) 拉取 / 推送印迹数据（记录、沉淀、经历库、岗位方向、简历信息库快照）
 *   3) 离线队列、世代戳冲突判定、401 自动登出
 *
 * 依赖全局（两版都有）：
 *   window.__yinji.state()      取当前印迹数据
 *   window.__yinji.loadState(d) 用云端数据覆盖本地并重绘
 *   window.__yinji.save()       触发一次本地保存
 * 独立记录版与完整版 App 共用这一份代码，UI 挂载点由 mount(root) 决定。
 * ======================================================================== */
(function () {
  'use strict';
  if (window.__yjsync) return;

  var APP = '印迹';
  /* 检查更新：与小蛋仓同一套 GitHub Release latest 逻辑。
     公开分发仓库 dzlssg/yinji-dist 只放不含真实简历的「公开版」zip。
     APP_VERSION 与根目录 VERSION 保持一致，tools/verify.py 会校验，发版时两处一起改。 */
  var APP_VERSION = String(window.YJ_APP_VERSION || '0.1.0').replace(/^v/i, '');
  var UPDATE_REPO = 'dzlssg/yinji-dist';
  var UPDATE_CACHE_KEY = 'yinji_update_cache';
  /* 与小蛋仓同一个 Supabase 项目；印迹的数据存在独立表 yinji_data，不与小蛋仓混用。
     anon key 是公开的匿名密钥，安全性靠表上的 RLS 策略保证。 */
  var CFG = window.YJ_SUPABASE || {
    url: 'https://vlyyxiuqsiukdubxuzgu.supabase.co',
    anon: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZseXl4aXVxc2l1a2R1Ynh1emd1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODUxNTMxNzgsImV4cCI6MjEwMDcyOTE3OH0.ukh7hrv9I67maZEL-ksvSf_qZ5W1-y_G-0GXNCWSorg'
  };
  var SB_URL = String(CFG.url || '').replace(/\/+$/, '');
  var SB_ANON = CFG.anon || '';
  /* 受限网络兜底：http(s) 页面优先走同源 /sb/ 转发，浏览器不必直连境外域名；
     端点不存在或转发失败时自动回退直连，静态托管与 file:// 打开都不受影响。 */
  var PROXY_BASE = /^https?:$/.test(location.protocol) ? (location.origin + '/sb') : '';
  var proxyUsable = !!PROXY_BASE;
  var lastNet = null;
  var TABLE = 'yinji_data';
  var AUTH_KEY = 'yinji_auth';
  var TS_KEY = 'yinji_sync_ts';
  var DIRTY_KEY = 'yinji_sync_dirty';
  var PUSH_DEBOUNCE = 2000;

  var auth = null;          /* {token,refresh,email,uid} */
  var syncing = false;
  var pendingPush = false;
  var pushTimer = null;
  var listeners = [];
  var mountedRoot = null;
  var suppressUntil = 0;    /* 云端拉取后的短暂静默期，避免「拉下来又推上去」 */
  var pollTimer = null;     /* 多设备联动：定时拉取另一台设备的改动 */
  var cloudReady = true;    /* 云端表是否已建（404 时置 false，设置页给建表引导） */

  /* ---------------- 基础工具 ---------------- */
  function $(s, r) { return (r || document).querySelector(s); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function toast(msg) {
    var t = document.getElementById('toast');
    if (!t) { try { console.log('[印迹同步]', msg); } catch (e) {} return; }
    t.textContent = msg;
    t.classList.add('on');
    clearTimeout(t._tm);
    t._tm = setTimeout(function () { t.classList.remove('on'); }, 2200);
  }
  function store(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function read(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function loadAuth() {
    try { auth = JSON.parse(read(AUTH_KEY) || 'null'); } catch (e) { auth = null; }
    if (!auth || !auth.token) auth = null;
    return auth;
  }
  function saveAuth(a) {
    auth = a;
    if (a) store(AUTH_KEY, JSON.stringify(a)); else { try { localStorage.removeItem(AUTH_KEY); } catch (e) {} }
    emit();
  }
  function netError(e, base) {
    var m = String((e && e.message) || e || '');
    var why = /AbortError|timeout/i.test(m) ? '请求超时' :
      (/Failed to fetch|NetworkError|Load failed/i.test(m) ? '网络不可达' : m);
    var via = (base && base !== SB_URL) ? '同源转发' : '直连云端';
    lastNet = { why: why, via: via, base: base || SB_URL, at: Date.now() };
    return new Error('连不上云端（' + why + ' · ' + via + '）。本地数据照常保存，不受影响。');
  }
  function sbFetch(path, opts, retry) {
    if (!SB_URL) return Promise.reject(new Error('未配置云端地址'));
    var n = retry || 0;
    var useProxy = !!(PROXY_BASE && proxyUsable);
    var base = useProxy ? PROXY_BASE : SB_URL;
    var ctl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
    var o = Object.assign({ cache: 'no-store' }, opts || {});
    if (ctl) o.signal = ctl.signal;
    var tm = ctl ? setTimeout(function () { try { ctl.abort(); } catch (e) {} }, 30000) : null;
    return fetch(base + path, o).then(function (r) {
      if (tm) clearTimeout(tm);
      /* 静态托管 / 普通 http.server 没有 /sb/ 端点：返回 404/501 HTML，
         关掉转发并回退直连重试一次（Supabase 自己的 JSON 404 不算） */
      if (useProxy && (r.status === 404 || r.status === 501 || r.status >= 502)) {
        return r.clone().text().then(function (t) {
          if (!/^\s*[{[]/.test(t) && !/"(error|code|msg|message|error_code)"\s*:/.test(t)) {
            proxyUsable = false;
            return sbFetch(path, opts, n);
          }
          return r;
        }, function () { proxyUsable = false; return sbFetch(path, opts, n); });
      }
      return r;
    }, function (e) {
      if (tm) clearTimeout(tm);
      var m = String((e && e.message) || e || '');
      if (useProxy) proxyUsable = false;     /* 转发不通 → 回退直连 */
      /* 网络抖动 / 超时最多重试两次；服务端 4xx/5xx 不重试 */
      if (n < 2 && /Failed to fetch|NetworkError|Load failed|AbortError|timeout/i.test(m)) {
        return new Promise(function (res) { setTimeout(res, n ? 1200 : 600); })
          .then(function () { return sbFetch(path, opts, n + 1); });
      }
      throw netError(e, base);
    });
  }
  function anonHeaders(extra) {
    return Object.assign({ apikey: SB_ANON, 'Content-Type': 'application/json' }, extra || {});
  }
  function authHeaders(extra) {
    return Object.assign({ apikey: SB_ANON, 'Content-Type': 'application/json' },
      auth && auth.token ? { Authorization: 'Bearer ' + auth.token } : {}, extra || {});
  }
  function emit() { listeners.forEach(function (f) { try { f(api()); } catch (e) {} }); renderCloudCard(); }
  function onChange(f) { listeners.push(f); return function () { listeners = listeners.filter(function (x) { return x !== f; }); }; }

  /* ---------------- 数据层：取 / 写 印迹状态 ---------------- */
  /* 简历编辑器整包（正文 / 格式 / 信息库 / 工作台）由父文档 window.__sync 提供，
     有它就一起上云，这样电脑端改简历、手机端也能同步过来；独立记录版没有则自动退回旧包。 */
  function docPack() {
    try {
      if (!window.__sync || !window.__sync.pack) return null;
      var p = window.__sync.pack();
      if (p) delete p.at;                 /* 时间戳每次都变，不能拿来做变更判定 */
      return p;
    } catch (e) { return null; }
  }
  function docApply(p) {
    try { if (p && window.__sync && window.__sync.apply) window.__sync.apply(p, true); }
    catch (e) { console.warn('印迹：恢复简历内容失败', e); }
  }
  function localState() {
    var s = null, doc = null;
    try { s = (window.__yinji && window.__yinji.state) ? window.__yinji.state() : null; }
    catch (e) {}
    doc = docPack();
    if (!s && !doc) return null;
    var out = {};
    if (s) for (var k in s) if (Object.prototype.hasOwnProperty.call(s, k)) out[k] = s[k];
    if (doc) out.__doc = doc;
    return out;
  }
  function applyCloud(payload) {
    try {
      suppressUntil = Date.now() + 2000;
      if (payload && payload.__doc) { docApply(payload.__doc); return; }
      if (window.__yinji && window.__yinji.loadState) window.__yinji.loadState(payload);
      else if (window.__yinji && window.__yinji.setState) window.__yinji.setState(payload);
    } catch (e) { console.warn('印迹：写入云端数据失败', e); }
  }
  function touch() {           /* 本地有改动 → 排一次推送 */
    if (!auth) return;
    if (Date.now() < suppressUntil) return;   /* 刚从云端拉下来，别又推回去 */
    store(DIRTY_KEY, '1');
    schedulePush();
  }
  function schedulePush() {
    if (!auth) return;
    clearTimeout(pushTimer);
    pushTimer = setTimeout(push, PUSH_DEBOUNCE);
  }

  /* ---------------- 云端读写 ---------------- */
  function cloudRow() {
    return sbFetch('/rest/v1/' + TABLE + '?select=payload,updated_at&user_id=eq.' + encodeURIComponent(auth.uid) + '&limit=1',
      { headers: authHeaders() }).then(function (r) {
        if (r.status === 401) throw new Error('登录已过期，请重新登录');
        if (r.status === 404) { cloudReady = false; emit(); throw new Error('云端数据表还没建：请在 Supabase SQL Editor 执行「印迹/云端建表.sql」'); }
        if (!r.ok) throw new Error('读取云端数据失败 ' + r.status);
        return r.json();
      }).then(function (rows) { cloudReady = true; return (rows && rows[0]) ? rows[0] : null; });
  }
  /* quiet：被「保存」按钮调用时静默，错误由保存流程统一说明，不弹两遍 toast */
  function push(force, quiet) {
    if (!auth) return Promise.resolve(false);
    if (syncing) { pendingPush = true; return Promise.resolve(false); }
    var s = localState();
    if (!s) return Promise.resolve(false);
    syncing = true; emit();
    var body = { user_id: auth.uid, payload: s, updated_at: new Date().toISOString() };
    return sbFetch('/rest/v1/' + TABLE + '?on_conflict=user_id', {
      method: 'POST',
      headers: authHeaders({ Prefer: 'resolution=merge-duplicates,return=minimal' }),
      body: JSON.stringify(body)
    }).then(function (r) {
      if (r.status === 401) throw new Error('登录已过期，请重新登录');
      if (r.status === 404) throw new Error('云端数据表还没建：请在 Supabase SQL Editor 执行「印迹/云端建表.sql」');
      if (!r.ok) throw new Error('写入云端失败 ' + r.status);
      cloudReady = true;
      store(TS_KEY, String(Date.now()));
      store(DIRTY_KEY, '');
      return true;
    }).catch(function (e) {
      if (String(e.message || e).indexOf('登录已过期') >= 0) { signOut(true); }
      else if (!quiet) { toast('云端同步失败：' + (e.message || e)); }
      return false;
    }).then(function (ok) {
      syncing = false; emit();
      if (pendingPush) { pendingPush = false; schedulePush(); }
      return ok;
    });
  }
  function pull(force) {
    if (!auth) return Promise.resolve(null);
    var local = localState();
    var hasLocal = !!(local && ((local.days && Object.keys(local.days).length) ||
      (local.cards && local.cards.length)));
    var dirty = read(DIRTY_KEY) === '1';
    var lastTs = Number(read(TS_KEY) || 0);
    return cloudRow().then(function (row) {
      if (!row) {                       /* 云端还是空的 → 把本地推上去 */
        if (hasLocal) return push(true).then(function () { return 'pushed'; });
        return 'empty';
      }
      var cloudTs = row.updated_at ? Date.parse(row.updated_at) : 0;
      var payload = row.payload;
      if (!payload) return 'empty';
      if (force) { applyCloud(payload); store(TS_KEY, String(cloudTs)); store(DIRTY_KEY, ''); return 'pulled'; }
      if (!hasLocal) { applyCloud(payload); store(TS_KEY, String(cloudTs)); store(DIRTY_KEY, ''); return 'pulled'; }
      if (dirty && cloudTs > lastTs) return 'conflict';   /* 两边都改过 → 让用户选 */
      if (cloudTs > lastTs) { applyCloud(payload); store(TS_KEY, String(cloudTs)); store(DIRTY_KEY, ''); return 'pulled'; }
      if (dirty) return push(true).then(function () { return 'pushed'; });
      return 'same';
    });
  }
  function syncNow() {
    if (!auth) return Promise.resolve('off');
    return pull().then(function (r) {
      if (r === 'conflict') { renderMerge(); return 'conflict'; }
      if (r === 'pushed') toast('已同步到云端');
      else if (r === 'pulled') toast('已从云端恢复最新数据');
      return r;
    });
  }

  /* ---------------- 认证 ---------------- */
  function signIn(email, password) {
    return sbFetch('/auth/v1/token?grant_type=password', {
      method: 'POST', headers: anonHeaders(),
      body: JSON.stringify({ email: email, password: password })
    }).then(function (r) {
      return r.text().then(function (t) {
        var j = {};
        try { j = JSON.parse(t); } catch (e) {}
        if (!r.ok) throw new Error(j.error_description || j.msg || j.message || ('登录失败 ' + r.status));
        return j;
      });
    }).then(function (j) {
      saveAuth({ token: j.access_token, refresh: j.refresh_token, email: j.user && j.user.email, uid: j.user && j.user.id, at: Date.now() });
      /* 登录即成功：云同步放后台，云端表未建 / 暂时不可用都不阻断登录 */
      setTimeout(function () {
        syncNow().catch(function (e) { toast('云端暂不可用：' + (e.message || e) + '（本地数据不受影响）'); });
      }, 0);
      return 'signed-in';
    });
  }
  function signUp(email, password) {
    return sbFetch('/auth/v1/signup', {
      method: 'POST', headers: anonHeaders(),
      body: JSON.stringify({ email: email, password: password, options: { data: { app: APP } } })
    }).then(function (r) {
      return r.text().then(function (t) {
        var j = {};
        try { j = JSON.parse(t); } catch (e) {}
        if (!r.ok) throw new Error(j.error_description || j.msg || j.message || ('注册失败 ' + r.status));
        return j;
      });
    }).then(function (j) {
      /* 没验证邮箱时 Supabase 不返回会话，需要用户点邮件确认后再登录 */
      if (j.access_token) {
        saveAuth({ token: j.access_token, refresh: j.refresh_token, email: j.user && j.user.email, uid: j.user && j.user.id, at: Date.now() });
        return 'signed-in';
      }
      return 'need-confirm';
    });
  }
  function signOut(silent) {
    saveAuth(null);
    store(DIRTY_KEY, '');
    if (!silent) toast('已退出账户，本地数据仍在');
    emit();
  }
  function changePassword(oldPw, newPw) {
    if (!auth) return Promise.reject(new Error('还没登录'));
    return signIn(auth.email, oldPw).then(function () {
      return sbFetch('/auth/v1/user', {
        method: 'PUT', headers: authHeaders(),
        body: JSON.stringify({ password: newPw })
      });
    }).then(function (r) {
      return r.json().then(function (j) {
        if (!r.ok) throw new Error(j.error_description || j.msg || j.message || ('改密失败 ' + r.status));
        return signIn(auth.email, newPw).then(function () { return true; });
      });
    });
  }

  /* ---------------- 弹层 UI（动态生成，样式与印迹一致） ---------------- */
  var CSS = [
    '#yjAuth{position:fixed;inset:0;z-index:340;display:none;align-items:center;justify-content:center;',
    'background:rgba(20,20,22,.28);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);font-family:-apple-system,BlinkMacSystemFont,"SF Pro SC","PingFang SC",Arial,sans-serif}',
    '#yjAuth.on{display:flex}',
    '#yjAuth .box{width:min(380px,92vw);max-height:calc(100dvh - 40px);overflow-y:auto;background:#fff;border-radius:20px;box-shadow:0 18px 60px rgba(0,0,0,.22);padding:24px 22px 20px}',
    '#yjAuth h4{margin:0 0 3px;font-size:16px;font-weight:650;color:#1d1d1f}',
    '#yjAuth .sub{margin:0 0 14px;font-size:12px;color:#8a8a8f;line-height:1.6}',
    '#yjAuth .tabs{display:inline-flex;gap:2px;padding:3px;background:#ececee;border-radius:10px;margin-bottom:14px}',
    '#yjAuth .tabs button{display:inline-flex;align-items:center;justify-content:center;line-height:1.2;min-height:36px;padding:8px 17px;border-radius:8px;font-size:12.5px;color:#6b6b70;font-weight:500}',
    '#yjAuth .tabs button.on{background:#fff;color:#1d1d1f;font-weight:600;box-shadow:0 1px 3px rgba(0,0,0,.08)}',
    '#yjAuth label{display:block;font-size:11.5px;color:#6b6b70;margin:10px 0 5px}',
    '#yjAuth input[type=email],#yjAuth input[type=password]{width:100%;padding:11px 12px;border:1px solid rgba(0,0,0,.12);border-radius:10px;font-size:16px;background:#fff}',
    '#yjAuth input:focus{outline:none;border-color:#f0b429;box-shadow:0 0 0 3px rgba(240,180,41,.14)}',
    '#yjAuth .go{width:100%;display:flex;align-items:center;justify-content:center;line-height:1.2;min-height:46px;margin-top:18px;padding:12px;border-radius:11px;background:linear-gradient(135deg,#f6d365,#fda085);',
    'color:#562804;font-size:14px;font-weight:650;border:0;cursor:pointer}',
    '#yjAuth .go:disabled{opacity:.55}',
    '#yjAuth .ghost{width:100%;display:flex;align-items:center;justify-content:center;line-height:1.2;min-height:42px;margin-top:8px;padding:11px;border-radius:11px;background:#f2f2f5;color:#1d1d1f;font-size:13px;border:0;cursor:pointer}',
    '#yjAuth .err{margin-top:12px;font-size:12px;color:#b3271e;line-height:1.6;background:#fff2f0;border:1px solid rgba(179,39,30,.12);border-radius:10px;padding:9px 11px}',
    '#yjAuth .err:empty{display:none}',
    '#yjAuth .tip{margin-top:14px;padding-top:12px;border-top:1px solid rgba(0,0,0,.06);font-size:11.5px;color:#8a8a8f;line-height:1.6;text-align:center}',
    '#yjAuth .who{display:flex;align-items:center;gap:10px;padding:12px;border:1px solid rgba(0,0,0,.08);border-radius:12px;background:#fbfbfd}',
    '#yjAuth .who .av{width:34px;height:34px;border-radius:10px;background:linear-gradient(135deg,#f6d365,#fda085);',
    'color:#fff;font-size:14px;font-weight:650;display:flex;align-items:center;justify-content:center;flex:0 0 34px}',
    '#yjAuth .who b{display:block;font-size:13px;color:#1d1d1f}',
    '#yjAuth .who span{font-size:11px;color:#8a8a8f}',
    '#yjAuth .row{display:flex;gap:8px;margin-top:12px}',
    '#yjAuth .row button{flex:1;display:flex;align-items:center;justify-content:center;line-height:1.2;min-height:42px;padding:11px;border-radius:11px;border:1px solid rgba(0,0,0,.12);background:#fff;font-size:13px;cursor:pointer;color:#1d1d1f}',
    '#yjAuth .row button.pri{background:#1d1d1f;color:#fff;border-color:#1d1d1f}',
    '#yjAuth .row button.dan{color:#c33}',
    '#yjAuth .dot{width:7px;height:7px;border-radius:50%;background:#d6d6db;display:inline-block;margin-right:6px;vertical-align:1px}',
    '#yjAuth .dot.on{background:#18a058}', '#yjAuth .dot.busy{background:#f0b429}', '#yjAuth .dot.err{background:#e5484d}',
    '@media screen and (max-width:600px){',
    '#yjAuth .box{width:calc(100vw - 32px);max-height:calc(100dvh - 32px);padding:22px 18px 18px;border-radius:18px}',
    '#yjAuth .tabs button{min-height:38px}',
    '#yjAuth .go{min-height:48px}',
    '}'
  ].join('');

  /* 侧栏账户条：印迹工作台在 Shadow DOM 里，父文档样式进不去，
     所以这份规则要单独一份，挂载时注入到 shadow 内。 */
  var ACCT_CSS = [
    '.acct{display:flex;align-items:center;gap:9px;padding:10px;border-radius:11px;border:1px solid var(--line);background:#fbfbfd;cursor:pointer;font-size:12px;color:var(--sub)}',
    '.acct:hover{border-color:rgba(240,180,41,.5)}',
    '.acct .av{width:26px;height:26px;border-radius:8px;background:linear-gradient(135deg,#f6d365,#fda085);color:#fff;overflow:hidden;',
    'font-size:11.5px;font-weight:650;display:flex;align-items:center;justify-content:center;flex:0 0 26px}',
    '.acct .av svg{display:block;width:100%;height:100%}',
    '.acct .tx{min-width:0;flex:1}',
    '.acct .tx b{display:block;font-size:12px;font-weight:600;color:var(--ink);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.acct .tx span{font-size:10.5px;color:var(--hint)}',
    '.acct .dot{width:7px;height:7px;border-radius:50%;background:#d6d6db;flex:0 0 7px}',
    '.acct .dot.on{background:#18a058}', '.acct .dot.busy{background:#f0b429}', '.acct .dot.err{background:#e5484d}'
  ].join('');

  /* 未登录时账户条用印迹正式 logo：渐变底沿用 .av，白点阵「由虚到实、由小到大」
     与侧栏品牌图标完全一致，不再用「印」字占位。不用 defs/id，多个挂载点不冲突。 */
  /* 设置页「云端同步」卡片：状态 + 手动同步 + 建表引导（动态挂载，两个版本通用） */
  var CLOUD_CSS = [
    '#yjCloudCard .yj-cstat{display:flex;align-items:center;gap:7px;font-size:12px;',
    'color:var(--sub,#6b6b70);line-height:1.6;margin:6px 0 2px}',
    '#yjCloudCard .yj-dot{width:8px;height:8px;border-radius:50%;background:#d6d6db;flex:0 0 8px}',
    '#yjCloudCard .yj-dot.on{background:#18a058}', '#yjCloudCard .yj-dot.busy{background:#f0b429}',
    '#yjCloudCard .yj-dot.err{background:#e5484d}',
    '#yjCloudCard .yj-warn{margin-top:10px;padding:10px 11px;border-radius:10px;font-size:11.5px;',
    'line-height:1.7;background:#fff6e5;color:#8a5a00;border:1px solid rgba(240,180,41,.32)}',
    '#yjCloudCard .yj-warn button{margin-top:9px}',
    '#yjCloudCard .yj-hint{margin-top:9px;font-size:11px;color:var(--hint,#8a8a8f);line-height:1.65}'
  ].join('');
  /* 设置页「关于 / 检查更新」卡片 + 更新弹窗（两版通用）。
     弹窗挂父文档 body，样式同时注入 document.head 与 shadow root，
     按钮样式自带一份，不依赖 shadow 内的 .btn 规则。 */
  var UPDATE_CSS = [
    '#yjUpdateCard .yj-upd-row{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}',
    '#yjUpdateCard .yj-upd-meta{display:flex;flex-direction:column;gap:2px}',
    '#yjUpdateCard .yj-upd-meta b{font-size:15px;font-weight:600;letter-spacing:.02em}',
    '#yjUpdateCard .yj-upd-meta span{font-size:11.5px;color:var(--hint,#9b9ba0)}',
    '#yjUpdateCard .yj-upd-hint{margin-top:10px;font-size:11px;color:var(--hint,#9b9ba0);line-height:1.65}',
    '#yjUpdateCard .btn[disabled]{opacity:.55;cursor:default;filter:none}',
    '.yj-upd-mask{position:fixed;inset:0;z-index:400;display:none;align-items:center;justify-content:center;',
    'padding:20px;background:rgba(29,29,31,.42);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px)}',
    '.yj-upd-mask.on{display:flex}',
    '.yj-upd-box{width:min(420px,100%);max-height:calc(100dvh - 40px);overflow-y:auto;',
    'background:rgba(255,255,255,.98);border:1px solid rgba(0,0,0,.06);border-radius:20px;',
    'box-shadow:0 18px 60px rgba(0,0,0,.22);padding:22px}',
    '.yj-upd-box h3{margin:0 0 12px;font-size:17px;font-weight:600;color:var(--ink,#1d1d1f)}',
    '.yj-upd-notes{font-size:12.5px;line-height:1.7;color:var(--sub,#6e6e73);white-space:pre-wrap;',
    'word-break:break-word;background:#f7f7f9;border-radius:12px;padding:12px 14px;',
    'max-height:220px;overflow:auto;margin-bottom:12px}',
    '.yj-upd-tip{font-size:11.5px;line-height:1.65;color:var(--hint,#9b9ba0);margin-bottom:14px}',
    '.yj-upd-actions{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}',
    '.yj-upd-actions .btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;',
    'padding:9px 14px;border:0;border-radius:10px;background:#ececee;color:#1d1d1f;',
    'font-family:inherit;font-size:12.5px;font-weight:500;cursor:pointer;white-space:nowrap}',
    '.yj-upd-actions .btn.primary{background:#1d1d1f;color:#fff}',
    '.yj-upd-actions .btn.ghost{background:transparent;border:1px solid rgba(0,0,0,.14);color:#6e6e73}',
    '.yj-upd-actions .btn[disabled]{opacity:.55;cursor:default}',
    '@media (max-width:420px){.yj-upd-actions .btn{flex:1 1 44%}}'
  ].join('');
  var SETUP_SQL = [
    'create table if not exists public.yinji_data (',
    '  user_id uuid primary key references auth.users(id) on delete cascade,',
    "  payload jsonb not null default '{}'::jsonb,",
    '  updated_at timestamptz not null default now()',
    ');',
    'alter table public.yinji_data enable row level security;',
    'create policy "yinji_own_row" on public.yinji_data for all',
    '  using (auth.uid() = user_id) with check (auth.uid() = user_id);',
    'grant select, insert, update, delete on public.yinji_data to authenticated;'
  ].join('\n');

  var ACCT_LOGO = '<svg viewBox="0 0 34 34" width="100%" height="100%" aria-hidden="true">' +
    '<circle cx="10.7" cy="23.3" r="1.2" fill="#fff" fill-opacity="0.25"/>' +
    '<circle cx="13.9" cy="20.1" r="1.7" fill="#fff" fill-opacity="0.44"/>' +
    '<circle cx="17.0" cy="17.0" r="2.2" fill="#fff" fill-opacity="0.63"/>' +
    '<circle cx="20.1" cy="13.9" r="2.9" fill="#fff" fill-opacity="0.82"/>' +
    '<circle cx="23.7" cy="10.3" r="3.9" fill="#fff" fill-opacity="1.00"/>' +
    '</svg>';
  var HTML = [
    '<div id="yjAuth" aria-hidden="true">',
    '<div class="box">',
    '<h4 id="yjAuthTitle">账户</h4>',
    '<p class="sub" id="yjAuthSub">与小蛋仓共用同一个账号：注册一次，两个 App 都能登录。</p>',
    '<div id="yjAuthBody"></div>',
    '<div class="err" id="yjAuthErr"></div>',
    '<div class="tip" id="yjAuthTip"></div>',
    '<div class="row" id="yjAuthRow"></div>',
    '</div></div>'
  ].join('');

  var mode = 'signin';
  function ensureUI() {
    if (document.getElementById('yjAuth')) return;
    var st = document.createElement('style'); st.id = 'yjAuthStyle'; st.textContent = CSS + ACCT_CSS;
    document.head.appendChild(st);
    var d = document.createElement('div'); d.id = 'yjAuthRoot'; d.innerHTML = HTML;
    document.body.appendChild(d);
    var box = document.getElementById('yjAuth');
    box.addEventListener('click', function (e) { if (e.target === box) closeModal(); });
  }
  function openModal(m) {
    ensureUI();
    if (m) mode = m;
    renderModal();
    document.getElementById('yjAuth').classList.add('on');
    document.getElementById('yjAuth').setAttribute('aria-hidden', 'false');
  }
  function closeModal() {
    var m = document.getElementById('yjAuth');
    if (m) { m.classList.remove('on'); m.setAttribute('aria-hidden', 'true'); }
  }
  function err(msg) { var e = document.getElementById('yjAuthErr'); if (e) e.textContent = msg || ''; }
  function tip(msg) { var e = document.getElementById('yjAuthTip'); if (e) e.textContent = msg || ''; }
  /* 云端返回的英文错误翻成能直接照做的中文 */
  function friendly(e) {
    var m = String((e && e.message) || e || '');
    if (/Invalid login credentials|invalid_credentials/i.test(m)) return '邮箱或密码不对。没注册过就切到「注册」先建账号。';
    if (/Email not confirmed/i.test(m)) return '邮箱还没验证，去收件箱点确认链接后再登录。';
    if (/User already registered/i.test(m)) return '这个邮箱已经注册过了，切到「登录」。';
    if (/Password should be|password is too weak/i.test(m)) return '密码太短，至少 6 位。';
    if (/too many requests|rate limit/i.test(m)) return '尝试太频繁，稍等一两分钟再试。';
    if (/Unexpected token|not valid JSON|Unexpected end of JSON/i.test(m)) return '云端返回异常，点「重试连接」再试一次。';
    return m;
  }
  function rowHTML(html) { var r = document.getElementById('yjAuthRow'); if (r) r.innerHTML = html; }

  function renderModal() {
    ensureUI();
    var body = document.getElementById('yjAuthBody');
    var tabs = document.getElementById('yjAuthTabs');
    var oldGo = document.getElementById('yjAuthGo'); if (oldGo) oldGo.remove();
    if (auth) {
      document.getElementById('yjAuthTitle').textContent = '我的账户';
      document.getElementById('yjAuthSub').textContent = '云端已连接；本地数据始终保留，改动会自动同步。';
      body.innerHTML = '<div class="who"><div class="av">' + esc((auth.email || '?').slice(0, 1).toUpperCase()) + '</div>' +
        '<div style="min-width:0"><b>' + esc(auth.email || '') + '</b>' +
        '<span><i class="dot ' + dotCls() + '"></i>' + esc(statusText()) + '</span></div></div>';
      rowHTML('<button id="yjAuthPw">改密码</button><button class="dan" id="yjAuthOut">退出登录</button>');
      document.getElementById('yjAuthOut').onclick = function () { signOut(); closeModal(); renderAccount(); };
      document.getElementById('yjAuthPw').onclick = function () { mode = 'pw'; renderModal(); };
      tip('本地数据留在这台设备，改动 2 秒后自动上云；数据各存各的，互不干扰。');
      return;
    }
    /* 未登录：登录 / 注册 两个分段 */
    document.getElementById('yjAuthTitle').textContent = '登录账号';
    document.getElementById('yjAuthSub').textContent = '多设备自动同步';
    if (!tabs) {
      tabs = document.createElement('div');
      tabs.className = 'tabs'; tabs.id = 'yjAuthTabs';
      tabs.innerHTML = '<button data-m="signin" class="' + (mode === 'signin' ? 'on' : '') + '">登录</button>' +
        '<button data-m="signup" class="' + (mode === 'signup' ? 'on' : '') + '">注册</button>';
      body.parentNode.insertBefore(tabs, body);
      tabs.addEventListener('click', function (e) {
        var b = e.target.closest('button[data-m]'); if (!b) return;
        mode = b.getAttribute('data-m'); err(''); renderModal();
      });
    } else {
      Array.prototype.forEach.call(tabs.querySelectorAll('button[data-m]'), function (b) {
        b.classList.toggle('on', b.getAttribute('data-m') === mode);
      });
    }
    if (mode === 'pw') {
      document.getElementById('yjAuthTitle').textContent = '修改密码';
      body.innerHTML = '<label>当前密码</label><input type="password" id="yjOldPw" placeholder="当前密码">' +
        '<label>新密码（至少 6 位）</label><input type="password" id="yjNewPw" placeholder="新密码">';
      rowHTML('<button class="pri" id="yjPwSave">保存新密码</button><button id="yjPwBack">返回</button>');
      document.getElementById('yjPwBack').onclick = function () { mode = 'account'; renderModal(); };
      document.getElementById('yjPwSave').onclick = function () {
        var o = document.getElementById('yjOldPw').value, n = document.getElementById('yjNewPw').value;
        if (!o || !n) { err('把两栏都填一下'); return; }
        changePassword(o, n).then(function () { err(''); mode = 'account'; toast('密码已更新'); renderModal(); renderAccount(); })
          .catch(function (e) { err(e.message || String(e)); });
      };
      return;
    }
    body.innerHTML = '<label>邮箱</label><input type="email" id="yjEmail" placeholder="you@example.com" autocomplete="email">' +
      '<label>密码</label><input type="password" id="yjPw" placeholder="至少 6 位" autocomplete="current-password">';
    rowHTML('');
    var btn = document.createElement('button');
    btn.className = 'go'; btn.id = 'yjAuthGo';
    btn.textContent = mode === 'signin' ? '登录' : '注册并发送确认邮件';
    btn.onclick = doAuth;
    body.parentNode.insertBefore(btn, document.getElementById('yjAuthErr'));
    tip(mode === 'signin' ? '与小蛋仓共用账号' : '注册后查收确认邮件');
  }
  function doAuth() {
    var em = (document.getElementById('yjEmail') || {}).value || '';
    var pw = (document.getElementById('yjPw') || {}).value || '';
    em = em.trim();
    if (!em || !pw) { err('邮箱和密码都要填'); return; }
    if (pw.length < 6) { err('密码至少 6 位'); return; }
    var btn = document.getElementById('yjAuthGo');
    if (btn) { btn.disabled = true; btn.textContent = '处理中…'; }
    err('');
    var p = mode === 'signin' ? signIn(em, pw) : signUp(em, pw);
    p.then(function (r) {
      if (r === 'need-confirm') { toast('注册成功，去邮箱点确认链接'); closeModal(); renderAccount(); }
      else { toast('已登录'); closeModal(); renderAccount(); }
    }).catch(function (e) {
      var msg = friendly(e);
      err(msg);
      if (/连不上云端|Failed to fetch|NetworkError|Load failed|timeout|AbortError/i.test(msg)) {
        rowHTML('<button class="ghost" id="yjAuthRetry">重试连接</button>' +
          '<button class="ghost" id="yjAuthSkip">先用本地，不登录</button>');
        var rb = document.getElementById('yjAuthRetry');
        if (rb) rb.onclick = function () { proxyUsable = !!PROXY_BASE; rowHTML(''); err(''); doAuth(); };
        var sk = document.getElementById('yjAuthSkip');
        if (sk) sk.onclick = function () { closeModal(); toast('已切到本地模式，数据照常保存'); };
      }
    })
      .then(function () { if (btn) { btn.disabled = false; btn.textContent = mode === 'signin' ? '登录' : '注册并发送确认邮件'; } });
  }
  /* 冲突：本地与云端都改过 → 让用户选保留哪边 */
  function renderMerge() {
    ensureUI();
    openModal('merge');
    var t = document.getElementById('yjAuthTabs'); if (t) t.remove();
    document.getElementById('yjAuthTitle').textContent = '两台设备都改过';
    document.getElementById('yjAuthSub').textContent = '选一个保留，另一个会被覆盖。';
    document.getElementById('yjAuthBody').innerHTML =
      '<div class="row"><button id="yjMergeCloud">用云端覆盖本地</button><button id="yjMergeLocal" class="pri">用本地覆盖云端</button></div>';
    document.getElementById('yjAuthRow').innerHTML = '';
    document.getElementById('yjAuthErr').textContent = '';
    document.getElementById('yjAuthTip').textContent = '';
    document.getElementById('yjMergeCloud').onclick = function () {
      pull(true).then(function () { closeModal(); toast('已用云端数据覆盖本地'); });
    };
    document.getElementById('yjMergeLocal').onclick = function () {
      push(true).then(function () { closeModal(); toast('已用本地数据覆盖云端'); });
    };
  }

  /* ---------------- 手动同步 / 多设备自动联动 ---------------- */
  /* 「保存」按钮专用：把当前整包立即、静默推一次云端。
     清掉 debounce 定时器，避免本地落盘触发的 touch() 两秒后又重复推一遍。
     返回 true=成功 / false=失败（表未建、网络异常）/ 'off'=未登录 / 'pending'=已有同步在进行。 */
  function afterSave() {
    if (!auth) return Promise.resolve('off');
    clearTimeout(pushTimer);
    if (syncing) { pendingPush = true; return Promise.resolve('pending'); }
    return push(true, true);
  }
  function needLogin() { toast('请先登录账号'); openModal(); return Promise.resolve(false); }
  function pushNow() {
    if (!auth) return needLogin();
    return push(true).then(function (ok) {
      toast(ok ? '已同步到云端 · 另一台设备切回页面即可看到' : '同步失败，请看提示');
      emit(); return ok;
    });
  }
  function pullNow() {
    if (!auth) return needLogin();
    if (!window.confirm('用云端数据覆盖这台设备上的内容？')) return Promise.resolve(false);
    return pull(true).then(function (r) {
      toast(r === 'pulled' ? '已从云端拉取最新数据' : (r === 'empty' ? '云端还没有数据' : '拉取失败'));
      emit(); return r;
    }).catch(function (e) { toast('拉取失败：' + (e.message || e)); });
  }
  function manualSync() {
    if (!auth) return needLogin();
    return syncNow().then(function (r) {
      if (r === 'same') toast('两边已经是最新');
      emit(); return r;
    }).catch(function (e) { toast('同步失败：' + (e.message || e)); });
  }
  function copySetupSql() {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(SETUP_SQL).then(function () { toast('已复制建表语句'); },
        function () { toast('复制失败，请用「印迹/云端建表.sql」'); });
      return;
    }
    var a = document.createElement('textarea'); a.value = SETUP_SQL;
    a.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0';
    document.body.appendChild(a); a.focus(); a.select();
    var ok = false; try { ok = document.execCommand('copy'); } catch (e) {}
    a.remove(); toast(ok ? '已复制建表语句' : '复制失败，请用「印迹/云端建表.sql」');
  }
  function cloudCardHTML() {
    return '<h3>云端同步 <span class="n">多设备联动</span></h3>' +
      '<div class="yj-cstat" id="yjCloudStat"></div>' +
      '<div class="row" style="margin-top:12px;flex-wrap:wrap">' +
      '<button class="btn primary" data-yj="push">↑ 同步到云端</button>' +
      '<button class="btn" data-yj="pull">↓ 从云端拉取</button>' +
      '<button class="btn ghost" data-yj="sync">⟳ 智能同步</button></div>' +
      '<div id="yjCloudWarn" class="yj-warn" style="display:none"></div>' +
      '<div class="yj-hint" id="yjCloudHint"></div>';
  }
  function renderCloudCard() {
    if (!mountedRoot) return;
    var card = mountedRoot.querySelector('#yjCloudCard'); if (!card) return;
    var stat = card.querySelector('#yjCloudStat'),
        warn = card.querySelector('#yjCloudWarn'),
        hint = card.querySelector('#yjCloudHint');
    if (!stat) return;
    var dot = !auth ? '' : (syncing ? 'busy' : (cloudReady ? 'on' : 'err'));
    var s = !auth ? '未登录 · 登录后电脑与手机自动互相联动'
      : (syncing ? '同步中…' : (cloudReady ? '云端已连接' : '云端数据表未建'));
    var t = Number(read(TS_KEY) || 0);
    if (auth && t) s += ' · 上次 ' + new Date(t).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
    stat.innerHTML = '<i class="yj-dot ' + dot + '"></i>' + esc(s);
    if (auth && !cloudReady) {
      warn.style.display = '';
      warn.innerHTML = '云端表 <b>public.yinji_data</b> 还没建。复制语句 → 打开 SQL Editor → Run 一次即可；本地数据一直照常保存，不会丢。<br>' +
        '<button class="btn" data-yj="copysql">复制建表语句</button> ' +
        '<a class="btn ghost" href="https://supabase.com/dashboard/project/vlyyxiuqsiukdubxuzgu/sql/new" ' +
        'target="_blank" rel="noopener" style="text-decoration:none">打开 SQL Editor</a>';
    } else { warn.style.display = 'none'; }
    hint.textContent = auth
      ? '改动 2 秒后自动上云；每 25 秒、以及切回本页时自动拉取另一台设备的最新数据。'
      : '与小蛋仓共用账号；数据各存各的，不混在一起。';
  }
  function ensureCloudCard() {
    if (!mountedRoot) return;
    var scope = mountedRoot.querySelector('#v-sync') || mountedRoot;
    var card = scope.querySelector('#yjCloudCard');
    if (!card) {
      if (mountedRoot.nodeType === 11) {
        if (!mountedRoot.querySelector('style[data-yj-cloud]')) {
          var st = document.createElement('style');
          st.setAttribute('data-yj-cloud', '1'); st.textContent = CLOUD_CSS;
          mountedRoot.appendChild(st);
        }
      } else if (!document.getElementById('yjCloudStyle')) {
        var s = document.createElement('style'); s.id = 'yjCloudStyle';
        s.textContent = CLOUD_CSS; document.head.appendChild(s);
      }
      card = document.createElement('div'); card.className = 'card'; card.id = 'yjCloudCard';
      card.innerHTML = cloudCardHTML();
      var acct = scope.querySelector('[data-acct]');
      if (acct && acct.parentNode === scope) scope.insertBefore(card, acct.nextSibling);
      else scope.appendChild(card);
      card.addEventListener('click', function (e) {
        var b = e.target.closest && e.target.closest('button[data-yj]'); if (!b) return;
        var act = b.getAttribute('data-yj');
        if (act === 'push') pushNow();
        else if (act === 'pull') pullNow();
        else if (act === 'sync') manualSync();
        else if (act === 'copysql') copySetupSql();
      });
    }
    renderCloudCard();
  }
  /* ==================== 检查更新（同小蛋仓） ====================
     compareVer + releases/latest + 5 分钟缓存 + 403/404 友好提示 + 更新说明弹窗。
     印迹是纯网页：去掉 Tauri / APK / 应用内下载进度，改为浏览器原生下载；
     资产优先取「公开版」zip（完整版含真实简历，只发在私有源仓库）。 */
  var updBusy = false;
  function compareVer(a, b) {
    var pa = String(a || '').replace(/^v/i, '').split('.').map(function (n) { return parseInt(n, 10) || 0; });
    var pb = String(b || '').replace(/^v/i, '').split('.').map(function (n) { return parseInt(n, 10) || 0; });
    while (pa.length < 3) pa.push(0);
    while (pb.length < 3) pb.push(0);
    for (var i = 0; i < 3; i++) {
      if (pa[i] > pb[i]) return 1;
      if (pa[i] < pb[i]) return -1;
    }
    return 0;
  }
  function updToast(msg) {
    var t = (mountedRoot && mountedRoot.querySelector && mountedRoot.querySelector('#toast')) ||
            document.getElementById('toast');
    if (!t) { try { console.log('[印迹更新]', msg); } catch (e) {} return; }
    t.textContent = msg;
    t.classList.add('on');
    clearTimeout(t._yjUpdTm);
    t._yjUpdTm = setTimeout(function () { t.classList.remove('on'); }, 2200);
  }
  function ensureUpdateStyle() {
    if (!document.getElementById('yjUpdateStyle')) {
      var st = document.createElement('style'); st.id = 'yjUpdateStyle';
      st.textContent = UPDATE_CSS; document.head.appendChild(st);
    }
    if (mountedRoot && mountedRoot.nodeType === 11 &&
        !mountedRoot.querySelector('style[data-yj-update]')) {
      try {
        var ss = document.createElement('style');
        ss.setAttribute('data-yj-update', '1'); ss.textContent = UPDATE_CSS;
        mountedRoot.appendChild(ss);
      } catch (e) {}
    }
  }
  function ensureUpdateCard() {
    if (!mountedRoot) return;
    ensureUpdateStyle();
    var scope = mountedRoot.querySelector('#v-sync') || mountedRoot;
    var card = scope.querySelector('#yjUpdateCard');
    if (!card) {
      card = document.createElement('div'); card.className = 'card'; card.id = 'yjUpdateCard';
      card.innerHTML =
        '<h3>关于印迹 <span class="n">版本与更新</span></h3>' +
        '<div class="yj-upd-row">' +
          '<div class="yj-upd-meta"><b>印迹</b>' +
            '<span id="yjUpdateVer">当前版本 v' + esc(APP_VERSION) + '</span></div>' +
          '<button class="btn primary" id="yjUpdateBtn" data-yj="checkUpdate">检查更新</button>' +
        '</div>' +
        '<div class="yj-upd-hint" id="yjUpdateHint">新版本由发版流程自动构建，公开包不含任何真实简历内容。</div>';
      var cloud = scope.querySelector('#yjCloudCard');
      if (cloud && cloud.parentNode === scope) scope.insertBefore(card, cloud.nextSibling);
      else scope.appendChild(card);
      card.addEventListener('click', function (e) {
        var b = e.target.closest && e.target.closest('[data-yj="checkUpdate"]');
        if (b) checkForUpdate(true);
      });
    }
    var v = scope.querySelector('#yjUpdateVer');
    if (v) v.textContent = '当前版本 v' + APP_VERSION;
  }
  function ensureUpdateUI() {
    ensureUpdateStyle();
    if (document.getElementById('yjUpdateMask')) return;
    var d = document.createElement('div'); d.id = 'yjUpdateRoot';
    d.innerHTML =
      '<div class="yj-upd-mask" id="yjUpdateMask" aria-hidden="true">' +
        '<div class="yj-upd-box" role="dialog" aria-modal="true" aria-label="检查更新">' +
          '<h3 id="yjUpdateTitle">发现新版本</h3>' +
          '<div class="yj-upd-notes" id="yjUpdateNotes"></div>' +
          '<div class="yj-upd-tip" id="yjUpdateTip"></div>' +
          '<div class="yj-upd-actions">' +
            '<button class="btn" data-yj="updClose">关闭</button>' +
            '<button class="btn ghost" data-yj="updPage">打开下载页</button>' +
            '<button class="btn primary" data-yj="updDl">立即下载</button>' +
          '</div>' +
        '</div>' +
      '</div>';
    document.body.appendChild(d);
    var mask = document.getElementById('yjUpdateMask');
    mask.addEventListener('click', function (e) {
      if (e.target === mask) { hideUpdateDialog(); return; }
      var b = e.target.closest && e.target.closest('button[data-yj]'); if (!b) return;
      var act = b.getAttribute('data-yj');
      if (act === 'updClose') hideUpdateDialog();
      else if (act === 'updPage') openUpdatePage(mask._releaseUrl);
      else if (act === 'updDl') openUpdatePage(mask._downloadUrl || mask._releaseUrl, true);
    });
  }
  function hideUpdateDialog() {
    var mask = document.getElementById('yjUpdateMask');
    if (!mask) return;
    mask.classList.remove('on'); mask.setAttribute('aria-hidden', 'true');
  }
  function openUpdatePage(url, isDownload) {
    if (!url) { updToast('暂无可用的下载链接'); return; }
    var w = window.open(url, '_blank', 'noopener');
    if (!w) updToast('浏览器拦截了新窗口，请手动访问下载页');
    else if (isDownload) updToast('已开始下载，请在浏览器下载列表查看');
    hideUpdateDialog();
  }
  function showUpdateDialog(version, notes, url, releaseUrl) {
    ensureUpdateUI();
    var mask = document.getElementById('yjUpdateMask');
    if (!mask) return;
    var title = document.getElementById('yjUpdateTitle');
    title.textContent = version ? '发现新版本 v' + version : '检查更新遇到问题';
    title.style.color = version ? 'var(--ink,#1d1d1f)' : '#8a5a00';
    document.getElementById('yjUpdateNotes').textContent = notes || '暂无更新说明';
    document.getElementById('yjUpdateTip').textContent = version
      ? '当前版本 v' + APP_VERSION + '；公开包可直接下载，完整版（含真实简历）在私有仓库获取。'
      : '可点「打开下载页」手动查看最新版本，或稍后重试。';
    mask._downloadUrl = url || '';
    mask._releaseUrl = releaseUrl || ('https://github.com/' + UPDATE_REPO + '/releases');
    var dl = mask.querySelector('[data-yj="updDl"]');
    dl.textContent = url ? '立即下载' : '前往 Release 页面';
    mask.classList.add('on'); mask.setAttribute('aria-hidden', 'false');
  }
  function checkForUpdate(manual) {
    if (updBusy) return Promise.resolve(false);
    updBusy = true;
    var btns = [];
    if (mountedRoot && mountedRoot.querySelector) {
      var b = mountedRoot.querySelector('#yjUpdateBtn'); if (b) btns.push(b);
    }
    var gb = document.getElementById('yjUpdateBtn');
    if (gb && btns.indexOf(gb) < 0) btns.push(gb);
    btns.forEach(function (btn) { btn.disabled = true; btn.textContent = '检查中…'; });
    var hint = document.getElementById('yjUpdateHint') ||
               (mountedRoot && mountedRoot.querySelector && mountedRoot.querySelector('#yjUpdateHint'));
    if (!UPDATE_REPO || UPDATE_REPO.indexOf('/') < 0) {
      updBusy = false;
      btns.forEach(function (btn) { btn.disabled = false; btn.textContent = '检查更新'; });
      updToast('检查更新失败：UPDATE_REPO 未配置');
      return Promise.resolve(false);
    }
    var api = 'https://api.github.com/repos/' + UPDATE_REPO + '/releases/latest';
    var now = Date.now();
    var cached = read(UPDATE_CACHE_KEY);
    var data = null;
    if (!manual && cached) {
      try { var c = JSON.parse(cached); if (c.ts && now - c.ts < 5 * 60 * 1000) data = c.data; } catch (e) {}
    }
    var got = data ? Promise.resolve(data) : fetch(api, {
      headers: { 'Accept': 'application/vnd.github+json' }
    }).then(function (res) {
      if (res.status === 403) throw new Error('HTTP 403：GitHub API 访问受限，可能是匿名接口限流。可稍后重试，或点「打开下载页」手动查看。');
      if (res.status === 404) throw new Error('HTTP 404：公开分发仓库 ' + UPDATE_REPO + ' 还没有发布过 Release；首次发版完成后这里就能查到更新。');
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return res.json();
    }).then(function (d) {
      store(UPDATE_CACHE_KEY, JSON.stringify({ ts: now, data: d }));
      return d;
    });
    return got.then(function (d) {
      var latest = String(d.tag_name || '').replace(/^v/i, '') || '0.0.0';
      var assets = d.assets || [];
      var pub = assets.filter(function (a) { return /公开版.*\.zip$/i.test(a.name || ''); })[0];
      var zip = assets.filter(function (a) { return /\.zip$/i.test(a.name || ''); })[0];
      var asset = pub || zip;
      if (compareVer(latest, APP_VERSION) > 0) {
        showUpdateDialog(latest, d.body || '', asset ? asset.browser_download_url : null, d.html_url);
        return true;
      }
      if (manual) updToast('已是最新版本 v' + APP_VERSION);
      if (hint) hint.textContent = '当前已是最新版本 v' + APP_VERSION + '。';
      return false;
    }).catch(function (e) {
      var msg = (e && e.message) || String(e);
      if (manual) {
        if (/HTTP 403|HTTP 404|UPDATE_REPO/.test(msg)) {
          showUpdateDialog(null, msg, null, 'https://github.com/' + UPDATE_REPO + '/releases');
        } else {
          updToast('检查更新失败：' + msg);
        }
      }
      if (hint) hint.textContent = '检查更新失败：' + msg;
      try { console.error('[印迹更新]', e); } catch (x) {}
      return false;
    }).then(function (r) {
      updBusy = false;
      btns.forEach(function (btn) { btn.disabled = false; btn.textContent = '检查更新'; });
      return r;
    });
  }
  function startPolling() {
    if (pollTimer) return;
    pollTimer = setInterval(function () {
      if (!auth || syncing || document.hidden || Date.now() < suppressUntil) return;
      pull().then(function (r) {
        if (r === 'pulled') { toast('已同步另一台设备的改动'); emit(); }
        else if (r === 'pushed') emit();
      }).catch(function () {});
    }, 25000);
  }

  /* ---------------- 状态显示 ---------------- */
  function dotCls() {
    if (!auth) return '';
    if (syncing) return 'busy';
    return 'on';
  }
  function statusText() {
    if (!auth) return '未登录';
    if (syncing) return '同步中…';
    return '云端已连接';
  }
  function api() {
    return {
      authed: !!auth, email: auth && auth.email, uid: auth && auth.uid,
      syncing: syncing, status: statusText(),
      cloudReady: cloudReady, lastSync: Number(read(TS_KEY) || 0)
    };
  }

  /* ---------------- 侧栏账户条（挂在印迹工作台 / 独立记录版侧栏） ---------------- */
  function renderAccount() {
    if (!mountedRoot) return;
    var boxes = mountedRoot.querySelectorAll('[data-acct]');
    if (!boxes.length) return;
    var html, cls;
    if (!auth) {
      html = '<div class="av yj-logo">' + ACCT_LOGO + '</div><div class="tx"><b>登录 / 注册</b>' +
        '<span>与小蛋仓共用账号</span></div><i class="dot"></i>';
      cls = '';
    } else {
      html = '<div class="av">' + esc((auth.email || '?').slice(0, 1).toUpperCase()) + '</div>' +
        '<div class="tx"><b>' + esc(auth.email || '') + '</b><span>' + esc(statusText()) + ' · 小蛋仓通用</span></div>' +
        '<i class="dot ' + dotCls() + '"></i>';
      cls = dotCls();
    }
    Array.prototype.forEach.call(boxes, function (box) {
      box.innerHTML = html;
      box.onclick = function () { openModal(); };
    });
  }
  function mount(root) {
    var r = root || document;
    if (r && r.nodeType === 11) ensureAcctStyle(r);   /* ShadowRoot：把账户条样式带进去 */
    if (mountedRoot === r) {
      renderAccount(); ensureCloudCard(); ensureUpdateCard(); ensureUpdateUI(); return;
    }
    mountedRoot = r;
    loadAuth();
    renderAccount();
    ensureCloudCard();
    ensureUpdateCard();   /* 设置页「关于印迹 · 检查更新」卡片（两版通用） */
    ensureUpdateUI();     /* 更新弹窗挂父文档 body，z-index 400 高于工作台 */
    startPolling();
    onChange(function () { renderAccount(); });
    if (auth) syncNow().catch(function (e) { toast('云端暂不可用：' + (e.message || e)); });
  }
  function ensureAcctStyle(root) {
    try {
      if (root.querySelector('style[data-yj-acct]')) return;
      var st = document.createElement('style');
      st.setAttribute('data-yj-acct', '1');
      st.textContent = ACCT_CSS;
      root.appendChild(st);
    } catch (e) {}
  }

  /* ---------------- 对外接口 ---------------- */
  window.__yjsync = {
    mount: mount,
    touch: touch,
    push: push,
    pull: pull,
    syncNow: syncNow,
    open: function () { openModal(); },
    close: closeModal,
    signOut: signOut,
    isAuthed: function () { return !!auth; },
    state: api,
    diag: function () {
      return { page: location.protocol + '//' + location.host, upstream: SB_URL,
        proxy: PROXY_BASE, proxyUsable: proxyUsable, lastNet: lastNet,
        authed: !!auth, online: navigator.onLine };
    },
    renderMerge: renderMerge,
    pushNow: pushNow, pullNow: pullNow, manualSync: manualSync, afterSave: afterSave,
    copySetupSql: copySetupSql, setupSql: SETUP_SQL,
    ensureCloudCard: ensureCloudCard,
    checkUpdate: checkForUpdate,
    compareVer: compareVer,
    appVersion: APP_VERSION,
    updateRepo: UPDATE_REPO,
    showUpdateDialog: showUpdateDialog,
    onChange: onChange
  };

  /* 初次加载 */
  loadAuth();
  startPolling();
  window.addEventListener('online', function () { if (auth) schedulePush(); });
  window.addEventListener('focus', function () { if (auth) syncNow().catch(function () {}); });
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden && auth) syncNow().catch(function () {});
  });
  document.addEventListener('DOMContentLoaded', function () {
    ensureUI();
    if (!mountedRoot) mount(document);
  });
})();
